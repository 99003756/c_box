practice: Redirection
1. Store error from a command to file.
2. Store output from a command to file.
3. Create a log file and append the errors to that file.
4. Feed inline input to a command
5. Feed output of one command as input to another.
6. Run a command that gives one output and one error.
7. Store output to a file and redirect error to display in the above command.

