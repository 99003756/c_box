Practice8: shell history
1. Issue the command 
echo The answer to the meaning of life, the universe and everything is 42.
2. Repeat the previous command using only two characters (there are two solutions!)
3. Display the last 5 commands you typed.
4. Issue the long echo from question 1 again, using the line numbers you received from the command in question 3.
5. How many commands can be kept in memory for your current shell session ?
6. Is the current session history stored to ~/.bashrc_history?
7. Where are these commands stored when exiting the shell ?
8. How many commands can be written to the history file when exiting your current shell session ?
9. Make sure your current bash shell remembers the only 10 commands you type.
10. When is command history written to the history file ?