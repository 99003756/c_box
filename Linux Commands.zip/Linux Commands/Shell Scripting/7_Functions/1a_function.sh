#!/bin/sh


function my_function () 
{
   echo "Hello World"
}

# Invoke the function
my_function