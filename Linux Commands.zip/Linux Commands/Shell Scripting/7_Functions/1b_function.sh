#!/bin/sh


my_function () 
{
   echo "Params are $1 $2"
}

# Invoke function
my_function Hi Hello