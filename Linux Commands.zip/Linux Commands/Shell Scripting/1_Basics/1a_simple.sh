#!/bin/bash
#This is a simple shell script.
echo "welcome to shell scripting"
echo -n "Today is "
date "+%d/%m/%Y"
exit 0	#Indication of successful or unseccessful termination
