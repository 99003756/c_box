#include "fun.h"
int square(int x) {
return x * x;
}