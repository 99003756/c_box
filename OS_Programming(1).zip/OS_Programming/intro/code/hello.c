int main() {
  int i;
  for(i=1;i<=5;i++)
    printf("hello:%d\n",i);
  return 0;
}
